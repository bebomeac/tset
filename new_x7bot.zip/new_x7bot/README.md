# [x7bot](https://telegram.me/bothu)

**An advanced and powerful administration bot based on NEW TG-CLI


* * *

## Commands

| Use help |
|:--------|:------------|
| [#!/]help | just send help in your group and get the commands |

**You can use "#", "!", or "/" to begin all commands


###A NEW BOT IN TELEGREM AND THE BEST
* * *

# التنصيب

git clone https://github.com/x7hh/new_x7bot.git
cd new_x7bot
chmod +x x7bot.sh
./x7bot.sh install
./x7bot.sh # Enter a phone number & confirmation cod

###ملاحظة   . 
### Sudo And Bot
After you run the bot for first time, send it `!id`. Get your ID and stop the bot.

Open ./bot/bot.lua and add your ID to the "sudo_users" section in the following format:
```
    sudo_users = {
    112235430,
    0,
    YourID
  }
```
add your bot ID at line 4 and add your ID at line 87 in bot.lua
add your ID at line 2 in tools.lua
Then restart the bot.

* * *

# Developers!

[جوكر بغداد](https://telegram.me/dev_iraq1)


### Our Telegram channel:

[x7 chaneel](https://telegram.me/bothu)
