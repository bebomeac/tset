#!/usr/bin/env bash


cd new_x7bot
chmod +x x7bot.sh
./x7bot.sh install
./x7bot.sh
./x7bot.sh install
./x7bot.sh



echo -e "${CYAN}Installation Completed! Create a bot with creator.lua (lua creator.lua)${NC}"

exit
--install.sh with lua by @dev_iraq1
